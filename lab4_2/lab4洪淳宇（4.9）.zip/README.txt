main.cpp 为主函数
Canvas.hpp 是Canvas类的声明
View.hpp 是View类的声明
Canvas.cpp 是Canvas类的定义
View.cpp 是View类的定义
inline.hpp 函数里是一个计算position的内联函数

