using namespace std;
#define BINARY 255
#define G "grayscale"
#define M "monochrome"
#include <iostream>
#include <cstring>
#include <vector>
#include <cmath>

#include "Canvas.hpp"
#include "asciis.h"

Canvas::Canvas(string option, int p_width, int p_height)
{
    while (1)
    {
        if (option == G)
        {
            flag_Canvas = 1;
            height = p_height;

            width = p_width;
            create_gray(width, height);
            break;
        }
        if (option == M) // option == M
        {
            true_width = p_width;
            flag_Canvas = 0;
            height = p_height;
            width = p_width / 8 + 1;
            create_mono(width, height);
            break;
        }
        else
        {
            cout << "please input the model again!" << endl;
            return;
        }
    }
}

void Canvas::printstr(int x, int y, string str)
{
    for (int i = 0; i < str.length(); i++)
    {
        if (flag_Canvas == 1)
            printchar_gray(x + 8 * i, y, str[i]); //转到真实位置
        else
            printchar_mono(x + 8 * i, y, str[i]);
    }
}

void Canvas::printchar_mono(int x, int y, char c)
{
    int int_c = (int)c;
    int pos = (int_c * 8) - 256;
    const unsigned char *const p = nAsciiDot + pos; // 找到在字符表里的位置
    const int x_pos = (x - 1) / 8;                  // canvas中的真实位置
    const int y_pos = height - y;                   // canvas中的真实位置
    const int right = (x - 1) % 8;                  //右移的位数
    const int left = 8 - right;                     // 左移的位数

    for (int i = 7; i >= 0; i--) // 对一个char的8个二进制数进行循环（字符表从上到下）（char从下到上）
    {
        if (y_pos + i - 7 > height - 1 || y_pos + i - 7 < 0) // 判断是否越界
            continue;
        const unsigned char *const p_now = p + i;

        unsigned char move_right = *(p_now) >> (right);                                   // 右移之后
        unsigned char move_left = *(p_now) << (left);                                     //左移之后
        dot_canvas[y_pos + i - 7][x_pos] = dot_canvas[y_pos + i - 7][x_pos] | move_right; // 变换前面的部分
        if (x_pos + 1 > width - 1)                                                        // 判断是否越界
            continue;
        dot_canvas[y_pos + i - 7][x_pos + 1] = dot_canvas[y_pos + i - 7][x_pos + 1] | move_left; // 变换后面的部分
    }
}

void Canvas::printchar_gray(int x, int y, char c) //在(x,y)处打印字符c
{
    int int_c = (int)c;
    int pos = (int_c * 8) - 256;
    const unsigned char *const p = nAsciiDot + pos + 8; // 找到在字符表里的位置
    for (int i = 8; i > 0; i--)                         // 对一个char的8个二进制数进行循环              为什么是8?
    {
        const unsigned char *const p_now = p - i;
        for (int j = 0; j < 8; j++) // 对一个二进制数的八位进行循环
        {
            if (x + j - 1 > width || height - y - i + 1 < 0) //如果超出画布范围
                continue;
            // dot[x+j][y+i] == pos(p_now, j) inline?
            dot_canvas[height - y - i + 1][x + j - 1] = (*p_now & (unsigned char)pow(2, 7 - j));
        }
    }
}

void Canvas::create_gray(int w, int h) //
{
    dot_canvas.resize(h);
    for (int i = 0; i < h; i++)
    {
        dot_canvas[i].resize(w);
    }
}

void Canvas::create_mono(int w, int h)
{
    dot_canvas.resize(h);
    for (int i = 0; i < h; i++)
    {
        dot_canvas[i].resize(w);
    }
}

void Canvas::printcanvas()
{
    if (flag_Canvas == 1)
        printcanvas_gray();
    else
        printcanvas_mono();
}

void Canvas::printcanvas_gray()
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            if (dot_canvas[i][j] == 0)
                cout << "o";
            else
                cout << ".";
        }
        cout << endl;
    }
}

void Canvas::printcanvas_mono()
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width - 1; j++)
        {
            for (int k = 7; k >= 0; k--)
            {
                if (((unsigned char)pow(2, k) & dot_canvas[i][j]) == 0) // 输出
                    cout << "o";
                else
                    cout << ".";
            }
        }
        for (int k = 7; k >= width * 8 - true_width; k--)
        {
            if (((unsigned char)pow(2, k) & dot_canvas[i][width - 1]) == 0) // 输出
                cout << "o";
            else
                cout << ".";
        }
        cout << endl;
    }
}

View::View(string option, int p_width, int p_height) //构造函数
{
    if (option == G)
    {
        flag_View = 1;
        height = p_height;

        width = p_width;
        create_gray(width, height);
    }
    else // option == M
    {
        true_width = p_width;
        flag_View = 0;
        height = p_height;
        width = p_width / 8 + 1;
        create_mono(width, height);
    }
}
void View::create_gray(int w, int h)
{
    dot_View.resize(h);
    for (int i = 0; i < h; i++)
    {
        dot_View[i].resize(w);
    }
}
void View::create_mono(int w, int h)
{
    dot_View.resize(h);
    for (int i = 0; i < h; i++)
    {
        dot_View[i].resize(w);
    }
}
void View::printstr(int x, int y, string str)
{
    for (int i = 0; i < str.length(); i++)
    {
        if (flag_View == 1)
            printchar_gray(x + 8 * i, y, str[i]); //转到真实位置
        else
            printchar_mono(x + 8 * i, y, str[i]);
    }
}
void View::printchar_gray(int x, int y, char c)
{
    int int_c = (int)c;
    int pos = (int_c * 8) - 256;
    const unsigned char *const p = nAsciiDot + pos + 8; // 找到在字符表里的位置
    for (int i = 8; i > 0; i--)                         // 对一个char的8个二进制数进行循环              为什么是8?
    {
        const unsigned char *const p_now = p - i;
        for (int j = 0; j < 8; j++) // 对一个二进制数的八位进行循环
        {
            if (x + j - 1 > width || height - y - i + 1 < 0) //如果超出画布范围
                continue;
            // dot[x+j][y+i] == pos(p_now, j) inline?
            dot_View[height - y - i + 1][x + j - 1] = (*p_now & (unsigned char)pow(2, 7 - j));
        }
    }
}
void View::printchar_mono(int x, int y, char c)
{
    int int_c = (int)c;
    int pos = (int_c * 8) - 256;
    const unsigned char *const p = nAsciiDot + pos; // 找到在字符表里的位置
    const int x_pos = (x - 1) / 8;                  // canvas中的真实位置
    const int y_pos = height - y;                   // canvas中的真实位置
    const int right = (x - 1) % 8;                  //右移的位数
    const int left = 8 - right;                     // 左移的位数

    for (int i = 7; i >= 0; i--) // 对一个char的8个二进制数进行循环（字符表从上到下）（char从下到上）
    {
        if (y_pos + i - 7 > height - 1 || y_pos + i - 7 < 0) // 判断是否越界
            continue;
        const unsigned char *const p_now = p + i;

        unsigned char move_right = *(p_now) >> (right);                               // 右移之后
        unsigned char move_left = *(p_now) << (left);                                 //左移之后
        dot_View[y_pos + i - 7][x_pos] = dot_View[y_pos + i - 7][x_pos] | move_right; // 变换前面的部分
        if (x_pos + 1 > width - 1)                                                    // 判断是否越界
            continue;
        dot_View[y_pos + i - 7][x_pos + 1] = dot_View[y_pos + i - 7][x_pos + 1] | move_left; // 变换后面的部分
    }
}
void View::line_gray(int x0, int y0, int x1, int y1) // lab1里的Bresenham画线算法
{
    int dx = x1 - x0;         // x偏移量
    int dy = y1 - y0;         // y偏移量
    int ux = dx > 0 ? 1 : -1; // x伸展方向
    int uy = dy > 0 ? 1 : -1; // y伸展方向
    int dx2 = abs(dx * 2);    // x偏移量乘2  （目的是出现整数）
    int dy2 = abs(dy * 2);    // y偏移量乘2
    if (abs(dx) > abs(dy))    //以x为增量方向计算
    {
        int e = -dx;         // e = -0.5 * 2 * dx,定义初始值 （原来的e是-0.5）
        int x = x0;          //起点x坐标
        int y = y0;          //起点y坐标
        while (x != x1 + ux) //在x到达终点后结束循环
        {
            dot_View[y][x] = 1;
            e = e + dy2; //（原来是 e = e + k）
            if (e > 0)   // e大于0时表示要取右上的点（否则是右下的点）
            {
                if (y != y1) //如果未到终点则继续增加
                {
                    y += uy;
                }
                e = e - dx2; // (原来是 e = e -1)
            }
            x += ux; //继续移动
        }
    }
    else
    { //以y为增量方向计算，其余与上面类似
        int e = -dy;
        int x = x0;
        int y = y0;
        while (y != y1 + uy)
        {
            dot_View[y][x] = 1;
            e = e + dx2;
            if (e > 0)
            {
                if (x != x1)
                {
                    x += ux;
                }
                e = e - dy2;
            }
            y += uy;
        }
    }
}
void View::line_mono(int _x0, int _y0, int _x1, int _y1) //直线版
{
    int x0 = _x0 + 1;
    int x1 = _x1 + 1;
    int y0 = _y0 + 1;
    int y1 = _y1 + 1;
    int dx = x1 - x0;         // x偏移量
    int dy = y1 - y0;         // y偏移量
    int ux = dx > 0 ? 1 : -1; // x伸展方向
    int uy = dy > 0 ? 1 : -1; // y伸展方向
    int x = x0;               //起点x坐标
    int y = y0;               //起点y坐标
    if (x0 == x1)
    {
        int x = x0 % 8;
        int pos_x = (x0 - 1) / 8;
        while (y != y1 + uy)
        {
            dot_View[height - y][pos_x] = dot_View[height - y][pos_x] | (unsigned char)pow(2, (8 - x) % 8);
            y += uy;
        }
    }
    if (y0 == y1)
    {
        if (x0 > x1) //如果大小相反就互换
        {
            int temp = x0;
            x0 = x1;
            x1 = temp;
            ux = 1;
        }
        int pos_x0 = (x0 - 1) / 8;
        int pos_x1 = (x1 - 1) / 8;
        // int pos_x = pos_x0;
        dot_View[height - y][pos_x0] =
            dot_View[height - y0][pos_x0] | (unsigned char)(pow(2, (8 - x0) % 8) - 1);
        for (int i = 1; i < (pos_x1 - pos_x0); i++)
        {
            dot_View[height - y0][i + pos_x0] = (unsigned char)255;
        }
        dot_View[height - y0][pos_x1] =
            dot_View[height - y0][pos_x1] | (unsigned char)(255 << (8 - (x1-1) % 8));
    }
}
void View::line(int x0, int y0, int x1, int y1)
{
    if (flag_View == 1)
        line_gray(x0, y0, x1, y1);
    else
        line_mono(x0, y0, x1, y1);
}
void Canvas::showViewAt(int x, int y, View V)
{
    if (flag_Canvas == 1)
        showViewAt_gray(x, y, V);
    else
        showViewAt_mono(x, y, V);
}
void Canvas::showViewAt_mono(int x, int y, View V)
{
    const int x_pos = (x - 1) / 8;     // canvas中的真实位置
    const int y_pos = height - y;      // canvas中的真实位置
    const int right = (x - 1) % 8;     //右移的位数
    const int left = 8 - right;        // 左移的位数
    for (int i = 0; i < V.height; i++) // 对一个char的8个二进制数进行循环（字符表从上到下）（char从下到上）
    {
        if (y_pos - i > height - 1 || y_pos - i < 0)
            continue;

        // unsigned char move_right = *(p_now)>>(right); // 右移之后
        // unsigned char move_left = *(p_now)<<(left); //左移之后
        for (int j = 0; j < V.width; j++)
        {
            if (x_pos + j > width - 1)
                continue;

            dot_canvas[y_pos - i][x_pos + j] =
                dot_canvas[y_pos - i][x_pos + j] | V.dot_View[V.height - i - 1][j] >> right; // 变换前面的部分
            if (x_pos + 1 + j > width - 1)
                continue;
            dot_canvas[y_pos - i][x_pos + 1 + j] =
                dot_canvas[y_pos - i][x_pos + 1 + j] | V.dot_View[V.height - i - 1][j] << left; // 变换后面的部分
        }
    }
}
void Canvas::showViewAt_gray(int x, int y, View V)
{
    for (int i = 0; i < V.height; i++)
    {
        for (int j = 0; j < V.width; j++)
        {
            dot_canvas[height - y - V.height + 1 + i][x - 1 + j] = V.dot_View[i][j];
        }
    }
}

// void View::test_View()
// {
//     if(flag_View == 1)
//         printview_gray();
//     else
//         printview_mono();
// }

int main()
{
    Canvas canvas("monochrome", 100, 80);
    View weatherView("monochrome", 80, 60);
    weatherView.printstr(5, 15, "020322");
    weatherView.printstr(5, 35, "temp:-1~5");
    // weatherView.line(0, 0, 0, 59);
    weatherView.line(0, 59, 79, 59);
    weatherView.line(79, 59, 79, 0);
    weatherView.line(0, 0, 79, 0);
    weatherView.line(0, 0, 0, 59);

    canvas.showViewAt(10, 10, weatherView);
    canvas.printcanvas();
    // Canvas canvas("grayscale", 100, 55);
    // canvas.printstr(10, 10, "OOP Lab4");
    // canvas.printstr(50, 50, "boundary");
    // canvas.printcanvas();
}

///// how to use const
///// mono_char √
///// define->inline
///// View -> new file
/////