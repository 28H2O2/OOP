#ifndef _Canvas_H_
#define _Canvas_H_

class View
{
    void create_gray(int, int);// grayscale
    void create_mono(int, int);// monochrome
    void printchar_gray(int, int, char );// private    
    void printchar_mono(int, int, char );// private
    void line_gray(int, int, int, int);
    void line_mono(int, int, int, int);
    int flag_View;// gray or mono
    
public:
    vector<vector<unsigned char>> dot_View;//需要从View直接访问？
    // void test_View();// 仅供测试
    // void printview_gray();//test
    // void printview_mono();//test
    void printstr(int, int, string);
    void line(int, int, int, int);
    int height; //高度(行数)
    int width;  //宽度(列数)
    int true_width;//monochrome状态下的真实宽度
    View();
    View(string, int, int);
};


class Canvas
{
protected:
    vector<vector<unsigned char>> dot_canvas;
    int height; //高度(行数)
    int width;  //宽度(列数)
    int true_width;//monochrome状态下的真实宽度
    int flag_Canvas;// gray or mono
    void create_gray(int, int);// grayscale
    void create_mono(int, int);// monochrome
    void printchar_gray(int, int, char );// private    

    void printcanvas_gray();
    void printcanvas_mono();
    void showViewAt_gray(int ,int, View);
    void showViewAt_mono(int ,int, View);
    // string G = "grayscale";
    // string M = "monochrome";
    

public:

    void printchar_mono(int, int, char );// private
    void printstr(int, int, string); //
    void showViewAt(int, int, View);
    void printcanvas();
    Canvas();                 // default function
    Canvas(string, int, int); // print dots
    ~Canvas(){
        cout<<"This program sucessfully finished!"<<endl;
    }                          
};



#endif


