#ifndef _MACRO_VEC_H_
#define _MACRO_VEC_H_



#include <vector>
#include <iostream>
#include <cstring>
using namespace std;

class Macro_vec
{
private:

public:
    // Macro_vec();
    vector<string> macro_name;
    vector<int> macro_func_num;
    vector<double> macro_line_length;
    vector<string> text_name;
    // vector<int> macro_height;
    
};




#endif