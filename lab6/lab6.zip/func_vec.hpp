#ifndef _FUNC_VEC_H_
#define _FUNC_VEC_H_



#include <vector>
#include <iostream>
#include <cstring>
using namespace std;

class Func_vec
{
private:

public:
    int func_num = 0;
    double line_length = 0;
    vector<string> func_text;

};




#endif