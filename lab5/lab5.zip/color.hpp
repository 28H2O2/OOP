#ifndef _COLOR_H_
#define _COLOR_H_

#include <vector>
#include <cstring>

class color
{
private:
    
public:

};

#endif